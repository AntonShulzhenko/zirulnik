Структура файлов должна быть такой:

<label class="input-group">
  <input type="text" class="твой класс">
</label>

https://jsfiddle.net/ojrnwp5h/

Добавляется класс "error-field" к .input-group его и стилизируешь по надобности.

Примеры:

вызов проверки на длину поля:

validation._length('твой класс', число символов); // твой класс строка

вызов проверки на подлинность E-mail:

validation._email('твой класс'); // твой класс строка